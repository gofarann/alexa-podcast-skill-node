Changes for Version 1.0
=======================

Botocore has been under beta/developer preview for a while now.  Before getting
to a stable 1.0 release, this document outlines the proposed changes that will
be made.


Changing the Model Schema
=========================
