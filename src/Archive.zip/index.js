'use strict';
var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback){
    var alexa = Alexa.handler(event, context, callback);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var WELCOME_MESSAGE = "Find a specific episode or discover new content.";


var handlers = {
    'LaunchRequest': function () {
         this.emit(':tell', WELCOME_MESSAGE);
     },

    'SearchByEpisodeNumberIntent': function () {
        this.emit(':tell', 'Episode found!');
    }

};
