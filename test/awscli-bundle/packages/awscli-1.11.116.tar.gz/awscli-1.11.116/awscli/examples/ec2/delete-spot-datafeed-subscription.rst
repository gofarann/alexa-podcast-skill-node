**To cancel a Spot Instance data feed subscription**

This example command deletes a Spot data feed subscription for the account. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-spot-datafeed-subscription
