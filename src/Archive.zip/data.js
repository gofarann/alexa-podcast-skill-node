
// =====================================================================================================
// --------------------------------- Section 1. Data and Text strings  ---------------------------------
// =====================================================================================================
//eventually move this to separate file?


module.exports = [
  { number: 2, title: 'Small Scale Sin', description: 'Small-scale stories on the nature of small-scale sin.', date: "1995-11-24" },
  { number: 3, title: 'Poultry Slam 1995', description: 'Stories decrying the wonders of turkeys, chickens, and other fowl.', date: "1995-12-01" },
];
